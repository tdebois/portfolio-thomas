import type { Metadata } from 'next';
export const metadata:Metadata={title:'Thomas — bezoekersgedeelte',description:'Portfolio en geregistreerd bezoekersgedeelte van Thomas Debois.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="nl"><head><link rel="stylesheet" href="/assets/bootstrap.css"/><link rel="stylesheet" href="/assets/theme.css"/><link rel="stylesheet" href="/assets/work.css"/><link rel="stylesheet" href="/assets/roots.css"/><link rel="stylesheet" href="/assets/members.css"/></head><body>{children}</body></html>}
