import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const members = sqliteTable('members', { userId: text('user_id').primaryKey(), name: text('name').notNull(), email: text('email').notNull(), createdAt: text('created_at').notNull() });
